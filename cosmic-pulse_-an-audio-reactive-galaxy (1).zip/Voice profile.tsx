export const angelicVoiceProfile = {
  name: 'Angelic Calm Female',
  timbre: 'soft-harmonic',
  pitch: 0.4,
  breathiness: 0.6,
  resonance: 'celestial',
  languageModel: 'poetic-v2',
  ambientSync: true,
};
